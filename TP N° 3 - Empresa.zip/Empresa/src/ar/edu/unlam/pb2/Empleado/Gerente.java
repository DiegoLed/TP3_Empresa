package ar.edu.unlam.pb2.Empleado;

public class Gerente extends Empleado{

	public Gerente(String nombre, Double salario, String fechaNacimiento) {
		super(nombre, salario, fechaNacimiento);

	}

}
