package ar.edu.unlam.pb2.Empleado;


public class Empleado {

	private String nombre;
	private Double salario;
	private String fechaNacimiento;

	public Empleado(String nombre, Double salario, String fechaNacimiento) {
		this.setNombre(nombre);
		this.setSalario(salario);
		this.setFechaNacimiento(fechaNacimiento);
	}

	public String brindarDetalle() {

		String nombreEmpleadoActual = this.getNombre();
		Double salarioEmpeadoActual = this.getSalario();
		String fechaNacimientoEmpleadoActual = this.getFechaNacimiento();
		return "Empleado [Nombre=" + nombreEmpleadoActual + ", Salario=" + salarioEmpeadoActual
				+ ", Fecha De Cumplea�os=" + fechaNacimientoEmpleadoActual + "]";

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Double getSalario() {
		return salario;
	}

	public void setSalario(Double salario) {
		this.salario = salario;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

}
