package ar.edu.unlam.pb2.Empleado;


public class Ingeniero extends Empleado{

	public Ingeniero(String nombre, Double salario, String fechaNacimiento) {
		super(nombre, salario, fechaNacimiento);

	}

}
