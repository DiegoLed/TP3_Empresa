package ar.edu.unlam.pb2.Empleado;


public class Secretaria extends Empleado {

	public Secretaria(String nombre, Double salario, String fechaNacimiento) {
		super(nombre, salario, fechaNacimiento);

	}

}
