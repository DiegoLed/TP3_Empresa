package ar.edu.unlam.pb2.Empleado;

public class ServicioImpuesto {

	private double SUELDO_GERENTE = 100000.00;
	private double SUELDO_INGENIERO = 50000.00;
	private double SUELDO_SECRETARIA = 20000.00;
	private double EXTRA_GASTOS = 10000.00;
	private double IMPUESTO_A_COBRAR_GERENTE = 0.80; //RETENCIONES 20%
	private double IMPUESTO_A_COBRAR_INGENIERO = 0.85; //RETENCIONES 15%
	private double IMPUESTO_A_COBRAR_SECRETARIA = 0.90; //RETENCIONES 10%
	
	
	public double obtenerImpuesto(Empleado miEmpleado) {

		if (miEmpleado.getSalario() == SUELDO_GERENTE) {
			double salarioGerenteConImpuesto = (SUELDO_GERENTE + EXTRA_GASTOS)*IMPUESTO_A_COBRAR_GERENTE;
			return salarioGerenteConImpuesto;  //$88000.00
		} else 
			if (miEmpleado.getSalario() == SUELDO_INGENIERO) {
				double salarioIngenieroConImpuesto =SUELDO_INGENIERO*IMPUESTO_A_COBRAR_INGENIERO;
				return salarioIngenieroConImpuesto;   //$42500.00
		} 
			else 
				if (miEmpleado.getSalario() == SUELDO_SECRETARIA) {
					double salarioSecretariaConImpuesto = SUELDO_SECRETARIA*IMPUESTO_A_COBRAR_SECRETARIA;
					return salarioSecretariaConImpuesto; //$18000.00
		}		else 
					return 0.00;

	}
	
}
