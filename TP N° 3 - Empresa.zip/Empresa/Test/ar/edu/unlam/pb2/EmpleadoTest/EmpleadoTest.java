package ar.edu.unlam.pb2.EmpleadoTest;

import org.junit.Assert;
import org.junit.Test;

import ar.edu.unlam.pb2.Empleado.Empleado;
import ar.edu.unlam.pb2.Empleado.Gerente;
import ar.edu.unlam.pb2.Empleado.Ingeniero;
import ar.edu.unlam.pb2.Empleado.Secretaria;
import ar.edu.unlam.pb2.Empleado.ServicioImpuesto;

public class EmpleadoTest {
	
	
	@Test
	public void mostrarLosDetallesDeLosEmpleados() {
		Empleado miGerente = new Gerente("Gonzalez, Jose", 100000.00,"01-01-1950");
		System.out.println(miGerente.brindarDetalle());
		
		Empleado miIngeniero = new Ingeniero("Fernandez, Alberto ", 50000.00,"01-02-1950");
		System.out.println(miIngeniero.brindarDetalle());
		
		Empleado miSecretaria = new Secretaria("Gomez, Juancita", 20000.00,"01-03-1950");
		System.out.println(miSecretaria.brindarDetalle());
	}
	
	@Test
	public void queImpuestoAGerenteSeaCorrecto(){
		Empleado miGerente = new Gerente("Gonzalez, Jose", 100000.00,"01-01-1950");
		ServicioImpuesto miImpuesto = new ServicioImpuesto();
		
		Double valorEsperado = 88000.00;
		Double valorActual = miImpuesto.obtenerImpuesto(miGerente);
	
		Assert.assertEquals(valorEsperado, valorActual);
	}
	
	@Test
	public void queImpuestoAIngenieroSeaCorrecto(){
		Empleado miIngeniero = new Ingeniero("Fernandez, Alberto ", 50000.00,"01-02-1950");
		ServicioImpuesto miImpuesto = new ServicioImpuesto();
		
		Double valorEsperado = 42500.00;
		Double valorActual = miImpuesto.obtenerImpuesto(miIngeniero);
		
		Assert.assertEquals(valorEsperado, valorActual);
	}
	
	@Test
	public void queImpuestoASecretariaSeaCorrecto(){
		Empleado miSecretaria = new Secretaria("Gomez, Juancita", 20000.00,"01-03-1950");
		ServicioImpuesto miImpuesto = new ServicioImpuesto();
		
		
		Double valorEsperado = 18000.00;
		Double valorActual = miImpuesto.obtenerImpuesto(miSecretaria);
	
		Assert.assertEquals(valorEsperado, valorActual);
	}
	
}
